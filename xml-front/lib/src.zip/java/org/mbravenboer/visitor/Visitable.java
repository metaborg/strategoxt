package org.mbravenboer.visitor;

/**
 * Tagging interface for a Visitable
 *
 * @author Martin Bravenboer
 * @version 1.0, 14/03/02
 */
public interface Visitable
{
}

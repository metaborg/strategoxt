package org.mbravenboer.application;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

public class Launcher {

  public static void main(String[] ps) {
    List<String> args = Arrays.asList(ps);

    String appClass = null;
    List<String> appArgs = null;

    // create an application
    if(args.size() > 0) {
      appClass = args.get(0);
    } else {
      System.err.println("Error: application class must be specified");
      System.exit(-1);
    } 

    Application application = null;
    try {
      application = (Application) Class.forName(appClass).newInstance();
    } catch(Exception exc) {
      System.err.println("Error: could not create instance of the specified application.");
      System.err.println("");
      application.printUsage();
      System.err.println("");
      System.exit(-1);
    }

    // create a map of arguments
    if(args.size() > 1) {
      appArgs = args.subList(1, args.size());
    } else {
      appArgs = new ArrayList<String>();
    }

    Map<String, String> mapArgs = null;
    try {
      mapArgs = toMap(appArgs);
    } catch(Exception exc) {
      System.err.println("Error: arguments are not well-formed");
      System.err.println("");
      application.printUsage();
      System.err.println("");
      System.exit(-1);
    }

    try {
      application.checkArguments(mapArgs);
    } catch(Exception exc) {
      System.err.println("Error: Invalid arguments. " + exc.getMessage());
      System.err.println("");
      application.printUsage();
      System.exit(-1);
    }

    // invoke the application
    try {
      application.invoke(mapArgs);
      System.err.println("");
    } catch(Exception exc) {
      System.err.println("Error: application terminated with an exception.");
      exc.printStackTrace(System.err);
      System.exit(-1);
    }
  }

  private static Map<String, String> toMap(List<String> args) throws Exception {
    Map<String, String> result = new HashMap<String, String>();

    Iterator<String> iterator = args.iterator();
    while(iterator.hasNext()) {
      String key = iterator.next();

      if(key.charAt(0) != '-') {
        throw new Exception("Invalid parameter key: " + key);
      }

      String value = iterator.next();

      result.put(key.substring(1), value);
    }

    return result;
  }
}

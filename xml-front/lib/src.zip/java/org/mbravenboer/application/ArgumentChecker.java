package org.mbravenboer.application;

import java.io.File;
import java.util.Map;
import java.text.SimpleDateFormat;

public class ArgumentChecker {

  private Map<String, String> _arguments;

  public ArgumentChecker(Map<String, String> arguments) {
    super();
    _arguments = arguments;
  }

  public void contains(String arg) throws Exception {
    if(!_arguments.containsKey(arg)) {
      throw new Exception("Argument " + arg + " is required.");
    }
  }

  public void isInt(String arg) throws Exception {
    try {
      Integer.parseInt(_arguments.get(arg));
    } catch(Exception exc) {
      throw new Exception("Value of argument " + arg + " is not an integer.");
    }
  }

  public void isBoolean(String arg) throws Exception {
    try {
      Boolean.valueOf(_arguments.get(arg));
    } catch(Exception exc) {
      throw new Exception("Value of argument " + arg + " is not a boolean.");
    }
  }

  public void isDate(String arg) throws Exception {
    try {
      SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
      format.parse(_arguments.get(arg));
    } catch(Exception exc) {
      throw new Exception("Value of argument " + arg + " is not a valid date.");
    }
  }

  public void isDirectory(String arg) throws Exception {
    File file = new File(_arguments.get(arg));

    if(!file.exists()) {
      throw new Exception("Value of argument " + arg + " does not exist.");
    }
    if(!file.isDirectory()) {
      throw new Exception("Value of argument " + arg + " is not a directory.");
    }
  }

  public void canReadFile(String arg) throws Exception {
    File file = new File(_arguments.get(arg));

    if(!file.canRead()) {
      throw new Exception("Cannot read the file contents of the value of argument " + arg + ".");
    }
  }

  public void canWriteFile(String arg) throws Exception {
    File file = new File(_arguments.get(arg));

    if(!file.canWrite()) {
      throw new Exception("Cannot write to value of argument " + arg + ".");
    }
  }
}

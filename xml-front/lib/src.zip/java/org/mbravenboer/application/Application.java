package org.mbravenboer.application;

import java.util.Map;

public interface Application {

  public void checkArguments(Map<String, String> arguments) throws Exception;
  public void invoke(Map<String, String> arguments) throws Exception;
  public void printUsage();
}

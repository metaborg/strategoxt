package org.mbravenboer.application;

import java.io.IOException;
import java.net.URL;
import java.util.Map;

public abstract class AbstractApplication implements Application {

  public void checkArguments(Map<String, String> arguments) throws Exception {
    checkArguments(new ArgumentChecker(arguments));
  }

  public void checkArguments(ArgumentChecker checker) throws Exception {
  }

  public void printUsage() {
    try {
      System.err.print(getUsage());
    } catch(Exception exc) {
      System.err.println(exc.getMessage());
    }
  }

  protected String getUsage() throws Exception {
    throw new Exception("Usage is not available");
  }
}


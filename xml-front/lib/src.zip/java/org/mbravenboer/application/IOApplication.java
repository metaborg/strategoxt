package org.mbravenboer.application;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import java.util.Map;

public abstract class IOApplication extends AbstractApplication {

  public void invoke(Map<String, String> arguments) throws Exception {
    InputStream input;
    if(arguments.containsKey("i")) {
      input = new FileInputStream(new File(arguments.get("i")));
    } else {
      input = System.in;
    }

    OutputStream output;
    if(arguments.containsKey("o")) {
      output = new FileOutputStream(new File(arguments.get("o")));
    } else {
      output = System.out;
    }

    invoke(input, output, arguments);

    input.close();
    output.close();
  } 

  public abstract void invoke(InputStream input, OutputStream output, Map<String, String> arguments)
    throws Exception;
}

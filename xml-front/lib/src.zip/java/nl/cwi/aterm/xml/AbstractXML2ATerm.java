package nl.cwi.aterm.xml;

import nl.cwi.aterm.xml.sax.Bridge;
import nl.cwi.aterm.ATermFactory;
import nl.cwi.aterm.output.ATermWriter;
import nl.cwi.aterm.pure.PureFactory;
import nl.cwi.aterm.saa.ATermBuilder;
import nl.cwi.aterm.saa.ATermContentHandler;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import org.mbravenboer.application.IOApplication;

public abstract class AbstractXML2ATerm extends IOApplication {

  public void invoke(InputStream input, OutputStream output, Map<String, String> arguments)
      throws Exception {

    ATermFactory factory = new PureFactory();
    ATermBuilder builder = new ATermBuilder(factory);

    ContentHandler bridge = createBridge(factory).toSAA(builder);
   
    // read the XML file with SAX

    SAXParserFactory saxFactory = SAXParserFactory.newInstance();
    saxFactory.setNamespaceAware(true);
    XMLReader reader = saxFactory.newSAXParser().getXMLReader();
    reader.setContentHandler(bridge);
    reader.parse(new InputSource(input));
   
    //Output the ATerm
    new ATermWriter(output).write(builder.getLastResult());
  }

  public abstract Bridge createBridge(ATermFactory factory);
}

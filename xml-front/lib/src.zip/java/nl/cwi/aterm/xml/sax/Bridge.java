package nl.cwi.aterm.xml.sax;

import nl.cwi.aterm.saa.ATermContentHandler;
import org.xml.sax.ContentHandler;

/**
 * Interface for a Bridge from SAA to SAX (and later vice versa).
 *
 * @author Martin Bravenboer, 
 *         <a href="mailto:mbravenb@cs.uu.nl">mbravenb@cs.uu.nl</a>
 * @version 0.5, 14-03-2002
 */
public interface Bridge {

    public ATermContentHandler toSAX(ContentHandler      handler);
    public ContentHandler      toSAA(ATermContentHandler handler);
}

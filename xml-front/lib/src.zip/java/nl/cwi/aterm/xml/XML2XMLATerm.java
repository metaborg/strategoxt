package nl.cwi.aterm.xml;

import nl.cwi.aterm.xml.sax.Bridge;
import nl.cwi.aterm.xml.sax.DefaultBridge;
import nl.cwi.aterm.ATermFactory;

public class XML2XMLATerm extends AbstractXML2ATerm {

  public Bridge createBridge(ATermFactory factory) {
    return new DefaultBridge(factory);
  }
}

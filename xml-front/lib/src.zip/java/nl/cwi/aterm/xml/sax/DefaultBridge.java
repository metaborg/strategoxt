package nl.cwi.aterm.xml.sax;

import nl.cwi.aterm.*;
import nl.cwi.aterm.saa.ATermContentHandler;
import nl.cwi.aterm.saa.helpers.NoAnnosHelper;
import nl.cwi.aterm.saa.SAAException;

import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.AttributesImpl;

/**
 * Default implementation for a Bridge from SAA to SAX
 *
 * @author Martin Bravenboer, 
 *         <a href="mailto:mbravenb@cs.uu.nl">mbravenb@cs.uu.nl</a>
 * @version 0.1, 26-05-2002
 */
public class DefaultBridge implements Bridge {
  
  private ATermFactory _factory;

  public DefaultBridge(ATermFactory factory) {
    super();
    _factory = factory;
  }

  public ATermContentHandler toSAX(ContentHandler handler) {
    throw new UnsupportedOperationException("Bridge.toSAX is not yet supported by this Bridge");
  }

  public ContentHandler toSAA(ATermContentHandler handler) {
    return new Explosion(handler, _factory);
  }
}

class Explosion implements ContentHandler {

  private NoAnnosHelper _contentHandler;

  public Explosion(ATermContentHandler contentHandler, ATermFactory factory) {
    super();
    _contentHandler = new NoAnnosHelper(contentHandler, factory);
  }

  private void throwMe(SAAException exc) throws SAXException {
    throw new SAXException(exc.getMessage(), exc);
  }

  public void characters(char[] ch, int start, int length)
      throws SAXException {
    try {
      String val = new String(ch, start, length).trim();
      if(val.length() > 0) {
        _contentHandler.startApplication("Text");
        _contentHandler.value(val);
        _contentHandler.endApplication();
      }
    } catch(SAAException exc) {
      throwMe(exc);
    }
  }

  public void startDocument()
      throws SAXException {
    try {
      _contentHandler.startSession();
      _contentHandler.startApplication("Document");
    } catch(SAAException exc) {
      throwMe(exc);
    }
  }

  public void endDocument()
      throws SAXException {
    try {
      _contentHandler.endApplication(); // of Document
      _contentHandler.endSession();
    } catch(SAAException exc) {
      throwMe(exc);
    }
  }

  public void startElement(String namespaceURI, String localName, String qName, Attributes atts)
      throws SAXException {
    try {
      _contentHandler.startApplication("Element");

      _contentHandler.startApplication("Name");
      if(namespaceURI.equals("") || namespaceURI == null) {
        noNamespace();
      } else {
        namespace(namespaceURI);
      }
      _contentHandler.value(localName);
      _contentHandler.endApplication();

      _contentHandler.startList(); // of Attributes
      int nrOfAtts = atts.getLength();
      for(int i = 0; i < nrOfAtts; i++) {
        _contentHandler.startApplication("Attribute");

        _contentHandler.startApplication("Name");
        if(atts.getURI(i).equals("")) {
          noNamespace();
        } else {
          namespace(atts.getURI(i));
        }
        _contentHandler.value(atts.getLocalName(i));
        _contentHandler.endApplication();

        _contentHandler.value(atts.getValue(i));

        _contentHandler.endApplication(); //of Attribute
      }
      _contentHandler.endList();

      _contentHandler.startList(); // of Content

    } catch(SAAException exc) {
      throwMe(exc);
    }
  }

  private void noNamespace() throws SAAException {
    _contentHandler.startApplication("None");
    _contentHandler.endApplication();
  }

  private void namespace(String uri) throws SAAException {
    _contentHandler.startApplication("Some");
      _contentHandler.startApplication("Namespace");
      _contentHandler.value(uri);
      _contentHandler.endApplication();
    _contentHandler.endApplication();
  }

  public void endElement(String namespaceURI, String localName, String qName)
      throws SAXException {
    try {
      _contentHandler.endList(); // of Content
      _contentHandler.endApplication(); // of Element
    } catch(SAAException exc) {
      throwMe(exc);
    }
  }

  public void startPrefixMapping(String prefix, String uri) {
    // ignore
  }

  public void endPrefixMapping(String prefix) {
    // ignore    
  }

  public void ignorableWhitespace(char[] ch, int start, int length) {
    // ignore
  }

  public void processingInstruction(String target, String data) {
    //ignore
  }

  public void setDocumentLocator(Locator locator) {
    //ignore
  }

  public void skippedEntity(String name) {
    //ignore
  }
}


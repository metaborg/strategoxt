package nl.cwi.aterm;

/**
 * @author Martin Bravenboer
 */
public class ATermFormat {

    public static final ATermFormat BINARY      = new ATermFormat();
    public static final ATermFormat TEXT        = new ATermFormat();
    public static final ATermFormat SHARED_TEXT = new ATermFormat();

}

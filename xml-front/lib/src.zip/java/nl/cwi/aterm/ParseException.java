package nl.cwi.aterm;

/**
 * A ParseException is thrown when an error occurs during the
 * parsing of a term.
 * Note that ParseException is a RuntimeException, so it can
 * be ignored if a parse error can only occur by a bug in
 * your program.
 * 
 * @author Hayco de Jong (jong@cwi.nl)
 * @author Pieter Olivier (olivierp@cwi.nl)
 * @version 1.0, 14/03/02
 */
public class ParseException extends RuntimeException {

  /**
   * Constructs a ParseException given a description of the error
   *
   * @param msg the error message describing the parse error.
   */
  public ParseException(String msg) {
    super(msg);
  }

  public ParseException(String msg, Exception cause) {
    super(msg, cause);
  }
}

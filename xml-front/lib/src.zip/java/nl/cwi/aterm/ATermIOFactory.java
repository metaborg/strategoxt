package nl.cwi.aterm;

import nl.cwi.aterm.input.ATermReader;
import nl.cwi.aterm.output.ATermWriter;

/**
 * An ATermIOFactory is reading and writing ATerms.
 * 
 * @author Martin Bravenboer
 */
public interface ATermIOFactory {

    public ATermReader createReader();
    public ATermWriter createWriter();
}

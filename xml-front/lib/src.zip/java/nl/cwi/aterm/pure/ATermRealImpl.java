package nl.cwi.aterm.pure;

import nl.cwi.aterm.*;
import nl.cwi.aterm.visitor.ATermCommandingGuide;
import nl.cwi.aterm.visitor.ATermVisitor;
import nl.cwi.aterm.visitor.ATermVisitFailure;

import java.util.List;

class ATermRealImpl extends ATermImpl implements ATermReal {
  double value;

  static int hashFunction(double value, ATermList annos) {
    long bits = Double.doubleToLongBits(value);
    int valHash = (int)(bits ^ (bits >>> 32));

    return Math.abs(valHash + annos.hashCode());
  }

  public int hashCode() {
    return hashFunction(value, annotations);
  }

  public int getType() {
    return ATerm.REAL;
  }

  protected ATermRealImpl(PureFactory factory, double value, ATermList annos) {
    super(factory, annos);
    this.value = value;
  }

  protected boolean match(ATerm pattern, List list) {
    if (this.equals(pattern)) {
      return true; 
    }

    if (pattern.getType() == ATerm.PLACEHOLDER) {
      ATerm type = ((ATermPlaceholder)pattern).getPlaceholder();
      if (type.getType() == ATerm.APPL) {
        ATermAppl appl = (ATermAppl)type;
        AFun afun = appl.getAFun();
        if(afun.getName().equals("real") && afun.getArity() == 0 && !afun.isQuoted()) {
          list.add(new Double(value));
          return true;
        }
      }
    }

    return super.match(pattern, list);
  }

  public double getReal() {
    return value;
  }

  public ATerm setAnnotations(ATermList annos) {
    return factory.makeReal(value, annos);
  }

  public void accept(ATermVisitor v) throws ATermVisitFailure {
    v.visit(this);
  }

  public void accept(ATermCommandingGuide g) throws ATermVisitFailure {
    g.guide(this);
  }
}

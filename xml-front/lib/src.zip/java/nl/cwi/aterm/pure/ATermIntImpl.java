package nl.cwi.aterm.pure;

import nl.cwi.aterm.*;
import nl.cwi.aterm.visitor.ATermCommandingGuide;
import nl.cwi.aterm.visitor.ATermVisitor;
import nl.cwi.aterm.visitor.ATermVisitFailure;

import java.util.List;

class ATermIntImpl extends ATermImpl implements ATermInt
{
  int value;

  static int hashFunction(int value, ATermList annos) {
    return Math.abs(value + annos.hashCode());
  }

  public int hashCode() {
    return hashFunction(value, annotations);
  }

  public int getType() {
    return ATerm.INT;
  }

  protected ATermIntImpl(PureFactory factory, int value, ATermList annos) {
    super(factory, annos);
    this.value = value;
  }

  protected boolean match(ATerm pattern, List list) {
    if (this.equals(pattern)) {
      return true; 
    }

    if (pattern.getType() == ATerm.PLACEHOLDER) {
      ATerm type = ((ATermPlaceholder)pattern).getPlaceholder();
      if (type.getType() == ATerm.APPL) {
	ATermAppl appl = (ATermAppl)type;
	AFun  afun = appl.getAFun();
	if(afun.getName().equals("int") && afun.getArity() == 0 && !afun.isQuoted()) {
	  list.add(new Integer(value));
	  return true;
	}
      }
    }

    return super.match(pattern, list);
  }

    public int getInt() {
        return value;
    }

    public ATerm setAnnotations(ATermList annos) {
        return factory.makeInt(value, annos);
    }

    public void accept(ATermVisitor v) throws ATermVisitFailure {
        v.visit(this);
    }

    public void accept(ATermCommandingGuide g) throws ATermVisitFailure {
        g.guide(this);
    }
}

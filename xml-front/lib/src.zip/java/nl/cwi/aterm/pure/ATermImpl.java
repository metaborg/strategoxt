package nl.cwi.aterm.pure;

import nl.cwi.aterm.*;
import nl.cwi.aterm.output.ATermWriter;
import nl.cwi.aterm.visitor.ATermVisitFailure;

import java.util.*;
import java.io.*;

abstract class ATermImpl implements ATerm
{
  ATermList annotations;
  PureFactory factory;
  private int hashcode;

  public int hashCode()
  {
    return hashcode;
  }

  protected void setHashCode(int hashcode)
  {
    this.hashcode = hashcode;
  }

  public ATermImpl(PureFactory factory, ATermList annos)
  {
    this.factory = factory;
    this.annotations = annos;
  }

  public ATermFactory getFactory()
  {
    return factory;
  }

  public ATerm setAnnotation(ATerm label, ATerm anno)
  {
    ATermList new_annos = annotations.dictPut(label, anno);
    ATerm result = setAnnotations(new_annos);

    return result;
  }

  public ATerm removeAnnotation(ATerm label)
  {
    return setAnnotations(annotations.dictRemove(label));
  }

  public ATerm getAnnotation(ATerm label)
  {
    return annotations.dictGet(label);
  }

  public ATerm removeAnnotations()
  {
    return setAnnotations(factory.makeList());
  }

  public ATermList getAnnotations()
  {
    return annotations;
  }

  public List match(String pattern) 
    throws ParseException
  {
    return match(factory.parsePattern(pattern));
  }

  public List match(ATerm pattern) 
  {
    List list = new LinkedList();
    if (match(pattern, list)) {
      return list;
    } else {
      return null;
    }
  }

  public boolean isEqual(ATerm term)
  {
    if(term instanceof ATermImpl) {
      return this == term;
    }

    return factory.isDeepEqual(this, term);
  }

  public boolean equals(Object obj)
  {
    if (obj instanceof ATermImpl) {
      return this == obj;
    }

    if (obj instanceof ATerm) {
      return factory.isDeepEqual(this, (ATerm)obj);
    }

    return false;
  }

  boolean match(ATerm pattern, List list)
  {
    if (pattern.getType() == PLACEHOLDER) {
      ATerm type = ((ATermPlaceholder)pattern).getPlaceholder();
      if (type.getType() == ATerm.APPL) {
	ATermAppl appl = (ATermAppl)type;
	AFun  afun = appl.getAFun();
	if(afun.getName().equals("term") && afun.getArity() == 0 && !afun.isQuoted()) {
	  list.add(this);
	  return true;
	}
      }
    }
    
    return false;
  }

  public ATerm make(List list)
  {
    return this;
  }

  public void writeToTextFile(ATermWriter writer)
    throws IOException
  {
    try {
      writer.visitChild(this);
      writer.getStream().flush();
    } catch (ATermVisitFailure e) {
      throw new IOException(e.getMessage());
    }
  }

  public void writeToSharedTextFile(OutputStream stream)
    throws IOException
  {
    ATermWriter writer = new ATermWriter(new BufferedOutputStream(stream));
    writer.initializeSharing();
    stream.write('!');
    writeToTextFile(writer);
  }

  public void writeToTextFile(OutputStream stream)
    throws IOException
  {
    ATermWriter writer = new ATermWriter(new BufferedOutputStream(stream));
    writeToTextFile(writer);
  }

  public String toString()
  {
    try {
      ByteArrayOutputStream stream = new ByteArrayOutputStream();
      ATermWriter writer = new ATermWriter(stream);
      writeToTextFile(writer);
      return stream.toString();
    } catch (IOException e) {
      throw new RuntimeException("IOException: " + e.getMessage());
    }
  }

  public int getNrSubTerms()
  {
    return 0;
  }

  public ATerm getSubTerm(int index)
  {
    throw new RuntimeException("no children!");
  }

  public ATerm setSubTerm(int index, ATerm t)
  {
    throw new RuntimeException("no children!");
  }
}

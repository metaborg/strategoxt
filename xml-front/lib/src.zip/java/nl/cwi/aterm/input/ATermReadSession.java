package nl.cwi.aterm.input;

import java.io.IOException;
import java.io.Reader;
import nl.cwi.aterm.ATerm;
import nl.cwi.aterm.ParseException;

class ATermReadSession {

  private static final int INITIAL_TABLE_SIZE = 2048;
  private static final int TABLE_INCREMENT    = 4096;

  private Reader reader;
  private int last_char;
  private int pos;

  private int nr_terms;
  private ATerm[] table;

  public ATermReadSession(Reader reader) {
    this.reader = reader;
    last_char   = -1;
    pos = 0;
  }

  public void initializeSharing()
  {
    table = new ATerm[INITIAL_TABLE_SIZE];
    nr_terms = 0;
  }

  public void storeNextTerm(ATerm t, int size) {
    if (table == null) {
      return;
    }

    if (size <= abbrevSize(nr_terms)) {
      return;
    }

    if (nr_terms == table.length) {
      ATerm[] new_table = new ATerm[table.length+TABLE_INCREMENT];
      System.arraycopy(table, 0, new_table, 0, table.length);
      table = new_table;
    }

    table[nr_terms++] = t;
  }

  public ATerm getTerm(int index) {
    if (index < 0 || index >= nr_terms) {
      throw new RuntimeException("illegal index");
    }
    return table[index];
  }

  public int read() throws IOException {
    last_char = reader.read();
    pos++;
    return last_char;
  }

  public int readSkippingWS() throws IOException {
    do {
      last_char = reader.read();
      pos++;
    } while (Character.isWhitespace((char)last_char));

    return last_char;

  }

  public int skipWS() throws IOException {
    while (Character.isWhitespace((char)last_char)) {
      last_char = reader.read();
      pos++;
    }

    return last_char;
  }

  public int readOct() throws IOException {
    int val = Character.digit((char)last_char, 8);
    val += Character.digit((char)read(), 8);

    if(val < 0) {
      throw new ParseException("octal must have 3 octdigits.");
    }

    val += Character.digit((char)read(), 8);

    if(val < 0) {
      throw new ParseException("octal must have 3 octdigits");
    }

    return val;
  }

  public int getLastChar() {
    return last_char;
  }

  public int getPosition() {
    return pos;
  }

  static public int abbrevSize(int abbrev) {
    int size = 1;

    if (abbrev == 0) {
      return 2;
    }

    while (abbrev > 0) {
      size++;
      abbrev /= 64;
    }

    return size;
  }
}


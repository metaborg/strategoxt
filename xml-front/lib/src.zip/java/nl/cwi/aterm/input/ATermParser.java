package nl.cwi.aterm.input;

import java.io.IOException;
import java.io.StringReader;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import nl.cwi.aterm.*;
import nl.cwi.aterm.ParseException;

class ATermParser {

  private ATermFactory _factory;

  public ATermParser(ATermFactory factory) {
    super();
    _factory = factory;
  }

  private ATerm parseAbbrev(ATermReadSession reader) throws IOException {

    ATerm result;
    int abbrev;

    int c = reader.read();

    abbrev = 0;
    while (isBase64(c)) {
      abbrev *= 64;
      if (c >= 'A' && c <= 'Z') { 
	abbrev += c - 'A';
      } else if (c >= 'a' && c <= 'z') {
	abbrev += c - 'a' + 26;
      } else if (c >= '0' && c <= '9') {
	abbrev += c - '0' + 52;
      } else if (c == '+') {
	abbrev += 62;
      } else if (c == '/') {
	abbrev += 63;
      } else {
	throw new RuntimeException("not a base-64 digit: " + c);
      }

      c = reader.read();
    }

    result = reader.getTerm(abbrev);

    return result;
  }

  private ATerm parseNumber(ATermReadSession reader)
    throws IOException
  {
    StringBuffer str = new StringBuffer();
    ATerm result;

    do {
      str.append((char)reader.getLastChar());
    } while(Character.isDigit((char)reader.read()));

    if(reader.getLastChar() != '.' && 
       reader.getLastChar() != 'e' && reader.getLastChar() != 'E') {
      int val;
      try {
	val = Integer.parseInt(str.toString());
      } catch (NumberFormatException e) {
	throw new ParseException("malformed int");
      }
      result = _factory.makeInt(val);
    } else {
      if(reader.getLastChar() == '.') {
	str.append('.');
	reader.read();
	if(!Character.isDigit((char)reader.getLastChar()))
	  throw new ParseException("digit expected");
	do {
	  str.append((char)reader.getLastChar());
	} while(Character.isDigit((char)reader.read()));
      }
      if(reader.getLastChar() == 'e' || reader.getLastChar() == 'E') {
	str.append((char)reader.getLastChar());
	reader.read();
	if(reader.getLastChar() == '-' || reader.getLastChar() == '+') {
	  str.append((char)reader.getLastChar());
	  reader.read();
	}
	if(!Character.isDigit((char)reader.getLastChar()))
	  throw new ParseException("digit expected!");
	do {
	  str.append((char)reader.getLastChar());
	} while(Character.isDigit((char)reader.read()));
      }
      double val;
      try {
	val = Double.valueOf(str.toString()).doubleValue();
      } catch (NumberFormatException e) {
	throw new ParseException("malformed real");
      }
      result = _factory.makeReal(val);    
    }
    return result;
  }

  private String parseId(ATermReadSession reader)
    throws IOException {
    int c = reader.getLastChar();
    StringBuffer buf = new StringBuffer(32);

    do {
      buf.append((char)c);
      c = reader.read();
    } while (Character.isLetterOrDigit((char)c) || c == '_' || c == '-');

    return buf.toString();
  }

  private String parseString(ATermReadSession reader)
    throws IOException {

    boolean escaped;
    StringBuffer str = new StringBuffer();
    
    do {
      escaped = false;
      if(reader.read() == '\\') {
        reader.read();
	escaped = true;
      }

      if(escaped) {
	switch(reader.getLastChar()) {
	case 'n':	str.append('\n');	break;
	case 't':	str.append('\t');	break;
	case 'b':	str.append('\b');	break;
	case 'r':	str.append('\r');	break;
	case 'f':	str.append('\f');	break;
	case '\\':	str.append('\\');	break;
	case '\'':	str.append('\'');	break;
	case '\"':	str.append('\"');	break;
	case '0':	case '1':	case '2':	case '3':
	case '4':	case '5':	case '6':	case '7':
	  str.append(reader.readOct());
	  break;
	default:	str.append('\\').append((char)reader.getLastChar());
	} 
      } else if(reader.getLastChar() != '\"')
	str.append((char)reader.getLastChar());
    } while(escaped || reader.getLastChar() != '"');

    return str.toString();
  }

  private ATermList parseATerms(ATermReadSession reader)
    throws IOException {

    ATerm[] terms = parseATermsArray(reader);
    ATermList result = _factory.makeList();
    for (int i=terms.length-1; i>=0; i--) {
      result = _factory.makeList(terms[i], result);
    }

    return result;
  }

  private ATerm[] parseATermsArray(ATermReadSession reader)
    throws IOException
  {
    List list = new Vector();
    ATerm term;

    term = parseFromReader(reader);
    list.add(term);
    while (reader.getLastChar() == ',') {
      reader.readSkippingWS();
      term = parseFromReader(reader);
      list.add(term);
    } 

    ATerm[] array = new ATerm[list.size()];
    ListIterator iter = list.listIterator();
    int index = 0;
    while (iter.hasNext()) {
      array[index++] = (ATerm)iter.next();
    }
    return array;
  }

  private ATerm parseFromReader(ATermReadSession reader)
    throws IOException {    

    ATerm result;
    int c, start, end;
    String funname;

    start = reader.getPosition();
    switch(reader.getLastChar()) {
      case -1:
	throw new ParseException("premature EOF encountered.");

      case '#':
	return parseAbbrev(reader);

      case '[':
	//{{{ Read a list

	c = reader.readSkippingWS();
	if (c == -1) {
	  throw new ParseException("premature EOF encountered.");
	}
	
	if(c == ']') {
	  c = reader.readSkippingWS();
	  result = (ATerm) _factory.makeList();
	} else {
	  result = parseATerms(reader);
	  if(reader.getLastChar() != ']') {
	    throw new ParseException("expected ']' but got '" + (char)reader.getLastChar() + "'");
	  }
	  c = reader.readSkippingWS();
	}

	//}}}
	break;

      case '<':
	//{{{ Read a placeholder

	c = reader.readSkippingWS();
	ATerm ph = parseFromReader(reader);
	
	if (reader.getLastChar() != '>') {
	  throw new ParseException("expected '>' but got '" + (char)reader.getLastChar() + "'");
	}

	c = reader.readSkippingWS();

	result = _factory.makePlaceholder(ph);

	//}}}
	break;

      case '"':
	//{{{ Read a quoted function

	funname = parseString(reader);
	
	c = reader.readSkippingWS();
	if (reader.getLastChar() == '(') {
	  c = reader.readSkippingWS();
	  if (c == -1) {
	    throw new ParseException("premature EOF encountered.");
	  }
	  if (reader.getLastChar() == ')') {
	    result = _factory.makeAppl(_factory.makeAFun(funname, 0, true));
	  } else {
	    ATerm[] list = parseATermsArray(reader);

	    if(reader.getLastChar() != ')') {
	      throw new ParseException("expected ')' but got '" + reader.getLastChar() + "'");
	    }
	    result = _factory.makeAppl(_factory.makeAFun(funname, list.length, true), list);
	  }
	  c = reader.readSkippingWS();
	  if (c == -1) {
	    throw new ParseException("premature EOF encountered.");
	  }
	} else {
	  result = _factory.makeAppl(_factory.makeAFun(funname, 0, true));
	}


	//}}}
	break;

      case '-':
      case '0':	case '1': case '2': case '3': case '4':
      case '5':	case '6': case '7': case '8': case '9':
        result = parseNumber(reader);
	c = reader.skipWS();
	break;

      default:
	c = reader.getLastChar();
	if (Character.isLetter((char)c)) {
	  //{{{ Parse an unquoted function
					 
	  funname = parseId(reader);
	  c = reader.skipWS();
	  if (reader.getLastChar() == '(') {
	    c = reader.readSkippingWS();
	    if (c == -1) {
	      throw new ParseException("premature EOF encountered.");
	    }
	    if (reader.getLastChar() == ')') {
	      result = _factory.makeAppl(_factory.makeAFun(funname, 0, false));
	    } else {
	      ATerm[] list = parseATermsArray(reader);

	      if(reader.getLastChar() != ')') {
		throw new ParseException("expected ')' but got '" + reader.getLastChar() + "'");
	      }
	      result = _factory.makeAppl(_factory.makeAFun(funname, list.length, false), list);
	    }
	    c = reader.readSkippingWS();
	  } else {
	    result = _factory.makeAppl(_factory.makeAFun(funname, 0, false));
	  }
	  
	  //}}}
	} else {
	  throw new ParseException("illegal character: " + reader.getLastChar());
	}
    }
	
    if(reader.getLastChar() == '{') {
      //{{{ Parse annotation

      ATermList annos;
      // Parse annotation
      if(reader.readSkippingWS() == '}') {
	reader.readSkippingWS();
	annos = _factory.makeList();;
      } else {
	annos = parseATerms(reader);
	if(reader.getLastChar() != '}') {
	  throw new ParseException("'}' expected");
	}
	reader.readSkippingWS();
      }
      result = result.setAnnotations(annos);	

      //}}}
    }

    /* Parse some ToolBus anomalies for backwards compatibility */
    if(reader.getLastChar() == ':') {
      reader.read();
      ATerm anno = parseFromReader(reader);
      result = result.setAnnotation(parse("type"), anno);
    }

    if(reader.getLastChar() == '?') {
      reader.readSkippingWS();
      result = result.setAnnotation(parse("result"), parse("true"));
    }

    end = reader.getPosition();
    reader.storeNextTerm(result, end-start);

    return result;    
  }

  //}}}

  //{{{ public ATerm parse(String trm)

  public ATerm parse(String trm)
  {
    try {
      ATermReadSession reader = new ATermReadSession(new StringReader(trm));
      reader.readSkippingWS();
      ATerm result = parseFromReader(reader);
      //System.out.println("parsing " + trm + " yields " + result);
      return result;
    } catch (IOException e) {
      throw new ParseException("premature end of string");
    }
  }

  static boolean isBase64(int c) {
    return Character.isLetterOrDigit((char)c) || c == '+' || c == '/';
  }

}


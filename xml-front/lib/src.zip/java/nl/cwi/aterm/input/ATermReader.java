package nl.cwi.aterm.input;

import java.io.InputStream;
import java.io.IOException;
import java.io.Reader;
import java.io.File;

import nl.cwi.aterm.ATerm;
import nl.cwi.aterm.ParseException;
import nl.cwi.aterm.saa.ATermContentHandler;

/**
 * ATermReader
 * 
 * @author Martin Bravenboer
 */
public interface ATermReader {

    public ATerm read(File file)           throws IOException, ParseException;
    public ATerm read(Reader reader)       throws IOException, ParseException;
    public ATerm read(InputStream stream)  throws IOException, ParseException;

    public ATerm read(File file, ATermContentHandler handler) throws IOException, ParseException;
    public void read(Reader reader, ATermContentHandler handler) throws IOException, ParseException;
    public void read(InputStream stream, ATermContentHandler handler) throws IOException, ParseException;
}

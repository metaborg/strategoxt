package nl.cwi.aterm.saa;

import nl.cwi.aterm.*;
import java.util.Stack;


/** 
 * Builds an ATerm from the logical content passed to this ATermContentHandler
 *
 * @author Martin Bravenboer, 
 *         <a href="mailto:mbravenb@cs.uu.nl">mbravenb@cs.uu.nl</a>
 * @version 0.1, 26-05-2002
 */
public class ATermBuilder implements ATermContentHandler {

  private ATermFactory _factory;
  private Stack<ATermContainer> _containers;

  private ATerm _lastResult;

  public ATermBuilder(ATermFactory factory) {
    super();
    _factory = factory;
  }

  public void startSession() throws SAAException {
    _containers = new Stack<ATermContainer>();
    _containers.push(new RootContainer());
  }

  public ATerm getLastResult() {
    return _lastResult;
  }

  public void endSession() throws SAAException {
    _lastResult = _containers.pop().getResult();

    if(!_containers.empty()) {
      throw new SAAException("Stack is not empty at end of session");
    }

    _containers = null;
  }

  private void add(ATerm term) {
    _containers.peek().add(term);
  }

  public void value(int value, ATermList annotation) throws SAAException {
    add(_factory.makeInt(value).setAnnotations(annotation));
  }

  public void value(String value, ATermList annotation) throws SAAException {
    add( _factory.makeAppl( _factory.makeAFun(value, 0, true)).setAnnotations(annotation));
  }

  public void value(double value, ATermList annotation) throws SAAException {
    add( _factory.makeReal(value).setAnnotations(annotation));
  }

  public void startApplication(String function, ATermList annotation) throws SAAException {
    _containers.push(new ApplicationContainer(_factory, function, annotation));
  }

  public void endApplication() throws SAAException {
    add(_containers.pop().getResult());
  }

  public void startList(ATermList annotation) throws SAAException {
    _containers.push(new ListContainer(_factory, annotation));
  }

  public void endList() throws SAAException {
    add(_containers.pop().getResult());
  }
}

interface ATermContainer {
  public void add(ATerm term);
  public ATerm getResult();
}

abstract class AbstractATermContainer implements ATermContainer {

  private ATermList _args;
  private ATermFactory _factory;

  public AbstractATermContainer(ATermFactory factory) {
    super();
    _args = factory.makeList();
    _factory = factory;
  }

  public void add(ATerm aterm) {
    _args = _args.append(aterm);
  }

  protected ATermList getArguments() {
    return _args;
  }
}

class ApplicationContainer extends AbstractATermContainer {

  private String _function;
  private ATermFactory _factory;
  private ATermList _annotation;

  public ApplicationContainer(ATermFactory factory, String function, ATermList annotation) {
    super(factory);
    _function = function;
    _factory = factory;
    _annotation = annotation;
  }

  public ATerm getResult() {
    ATermList arguments = getArguments();
    AFun fun = _factory.makeAFun(_function, arguments.getLength(), false);
    return _factory.makeAppl(fun, arguments).setAnnotations(_annotation);
  }

}

class ListContainer extends AbstractATermContainer {

  private ATermList _annotation;

  public ListContainer(ATermFactory factory, ATermList annotation) {
    super(factory);
    _annotation = annotation;
  }

  public ATerm getResult() {
    return getArguments().setAnnotations(_annotation);
  }
}

class RootContainer implements ATermContainer {
  private ATerm _root;

  public void add(ATerm term) {
    if(_root != null) {
      throw new RuntimeException("More than one elements found in root");
    }

    _root = term;
  }

  public ATerm getResult() {
    if(_root == null) {
      throw new RuntimeException("No terms found");
    }

    return _root;
  }
} 

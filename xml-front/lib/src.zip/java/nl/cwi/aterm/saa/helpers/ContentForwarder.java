package nl.cwi.aterm.saa.helpers;

import nl.cwi.aterm.AFun;
import nl.cwi.aterm.ATerm;
import nl.cwi.aterm.ATermList;
import nl.cwi.aterm.saa.ATermContentHandler;
import nl.cwi.aterm.saa.SAAException;

/**
 * Forwards all contents to another ATermContentHandler.
 *
 * @author Martin Bravenboer, 
 *         <a href="mailto:mbravenb@cs.uu.nl">mbravenb@cs.uu.nl</a>
 * @version 1.0, 26-05-2002
 */
public class ContentForwarder implements ATermContentHandler {

  private ATermContentHandler _to;

  public ContentForwarder(ATermContentHandler to) {
    super();
    _to = to;
  }

  public void startSession() throws SAAException {
    _to.startSession();
  }

  public void endSession() throws SAAException {
    _to.endSession();
  }

  public void value(int value, ATermList annotation) throws SAAException {
    _to.value(value, annotation);
  }

  public void value(String value, ATermList annotation) throws SAAException {
    _to.value(value, annotation);
  }

  public void value(double value, ATermList annotation) throws SAAException {
    _to.value(value, annotation);
  }

  public void startApplication(String function, ATermList annotation) throws SAAException {
    _to.startApplication(function, annotation);
  }

  public void endApplication() throws SAAException {
    _to.endApplication();
  }

  public void startList(ATermList annotation) throws SAAException {
    _to.startList(annotation);
  }

  public void endList() throws SAAException {
    _to.endList();
  }
}

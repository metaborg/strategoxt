package nl.cwi.aterm.saa;

public class SAAException extends Exception {

    public SAAException(String msg) {
        super(msg);
    }

    public SAAException(String msg, Exception cause) {
        super(msg, cause);
    }
}

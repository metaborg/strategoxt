package nl.cwi.aterm.saa;

import org.xml.sax.InputSource;

/**
 * Interface for reading an ATerm using callbacks.
 *
 * @author Martin Bravenboer, 
 *         <a href="mailto:mbravenb@cs.uu.nl">mbravenb@cs.uu.nl</a>
 * @version 0.5, 14-03-2002
 */
public interface ATermCallbackReader {

    public void parse(InputSource source, ATermContentHandler handler)
        throws SAAException;
}

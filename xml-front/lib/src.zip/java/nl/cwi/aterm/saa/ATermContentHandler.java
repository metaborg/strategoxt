package nl.cwi.aterm.saa;

import nl.cwi.aterm.AFun;
import nl.cwi.aterm.ATerm;
import nl.cwi.aterm.ATermList;

import org.mbravenboer.visitor.Visitor;

/**
 * Receive notification of the logical content of an ATerm.
 *
 * @author Martin Bravenboer, 
 *         <a href="mailto:mbravenb@cs.uu.nl">mbravenb@cs.uu.nl</a>
 * @version 0.5, 14-03-2002
 */
public interface ATermContentHandler {

    public void startSession() throws SAAException;
    public void endSession() throws SAAException;

    public void value(int value, ATermList annotation) throws SAAException;
    public void value(String value, ATermList annotation) throws SAAException;
    public void value(double value, ATermList annotation) throws SAAException;

    public void startApplication(String function, ATermList annotation) throws SAAException;
    public void endApplication() throws SAAException;

    public void startList(ATermList annotation) throws SAAException;
    public void endList() throws SAAException;
}

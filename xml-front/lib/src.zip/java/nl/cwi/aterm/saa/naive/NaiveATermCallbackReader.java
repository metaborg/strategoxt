package nl.cwi.aterm.saa.naive;

import nl.cwi.aterm.*;
import nl.cwi.aterm.saa.*;
import nl.cwi.aterm.visitor.ATermVisitFailure;
import nl.cwi.aterm.visitor.helpers.DefaultATermCommandedVisitor;
import nl.cwi.aterm.visitor.CommandingTopDownGuide;

import org.xml.sax.InputSource;

import java.io.IOException;

/**
 * Naive implementation of an ATermCallbackReader.
 *
 * <p>
 * This implementation just creates an ATerm and traverses
 * the content of this term to send events to the specified
 * ATermContentHandler.
 * </p>
 *
 * @author Martin Bravenboer, 
 *         <a href="mailto:mbravenb@cs.uu.nl">mbravenb@cs.uu.nl</a>
 * @version 0.5, 14-03-2002
 */
public class NaiveATermCallbackReader implements ATermCallbackReader {

    private ATermFactory _factory;

    /**
     * Constructs a new NaiveATermCallbackReader which will use the specified ATermFactory.
     */
    public NaiveATermCallbackReader(ATermFactory factory) {
        super();
        _factory = factory;
    }

    /**
     * Parses the ATerm of the specified InputSource and sends the content of
     * the term to the specified ATermContentHandler.
     */
    public void parse(InputSource source, ATermContentHandler handler) 
        throws SAAException
    {
        try {
            ATerm term = _factory.readFromFile(source.getByteStream());

            handler.startSession();
    
            term.accept(
                new CommandingTopDownGuide(new ATermToContentHandler(handler)));
    
            handler.endSession();
        }
        catch(ATermVisitFailure exc) {
            throw new SAAException("Term hasn't been sent to the handler completely", exc);
        }
        catch(IOException exc) {
            throw new SAAException("Term cannot be read from the specified InputSource", exc);
        }
    }
}

/**
 * Visitor for the ATerm which just sends events to the ATermContentHandler.
 */
class ATermToContentHandler extends DefaultATermCommandedVisitor {

    private ATermContentHandler _handler;

    public ATermToContentHandler(ATermContentHandler handler) {
        super();
        _handler = handler;
    }

    public void discover(ATermInt arg)  throws ATermVisitFailure {
        try {
            _handler.value(arg.getInt(), arg.getAnnotations());
        }
        catch(SAAException exc) {
            throw new ATermVisitFailure("", exc);
        }
    }

    public void discover(ATermReal arg) throws ATermVisitFailure {
        try {
            _handler.value(arg.getReal(), arg.getAnnotations());
        }
        catch(SAAException exc) {
            throw new ATermVisitFailure("", exc);
        }
    }
    
    public void discover(ATermAppl arg) throws ATermVisitFailure {
        try {
            //TODO seperate this in a String for now. Discuss whether this is
            //an attractive solution or not.

            if(arg.getAFun().isQuoted() && arg.getArity() == 0) {
                _handler.value(arg.getAFun().getName(), arg.getAnnotations());
            }
            else {
                _handler.startApplication(arg.getAFun().getName(), arg.getAnnotations());
            }
        }
        catch(SAAException exc) {
            throw new ATermVisitFailure("", exc);
        }
    }

    public void leave(ATermAppl arg) throws ATermVisitFailure {
        try {
            //TODO seperate this in a String for now. Discuss whether this is
            //an attractive solution or not.

            if(arg.getAFun().isQuoted() && arg.getArity() == 0) {
            }
            else {
                _handler.endApplication();
            }
        }
        catch(SAAException exc) {
            throw new ATermVisitFailure("", exc);
        }
    }

    public void discover(ATermList arg) throws ATermVisitFailure {
        try {
            _handler.startList(arg.getAnnotations());        
        }
        catch(SAAException exc) {
            throw new ATermVisitFailure("", exc);
        }
    }

    public void leave(ATermList arg) throws ATermVisitFailure {
        try {
            _handler.startList(arg.getAnnotations());        
        }
        catch(SAAException exc) {
            throw new ATermVisitFailure("", exc);
        }
    }

    public void discover(ATermPlaceholder arg) throws ATermVisitFailure {
        //TODO: find out a way to implement placeholder. What is a PlaceHolder?
        throw new RuntimeException("Placeholder is currently not implemented");
    }

    public void discover(ATermBlob arg) throws ATermVisitFailure {
        //TODO: find out a way to implement blob        
        throw new RuntimeException("Blob is currently not implemented");
    }
}

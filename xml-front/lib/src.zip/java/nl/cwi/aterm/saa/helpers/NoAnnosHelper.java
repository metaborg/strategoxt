package nl.cwi.aterm.saa.helpers;

import nl.cwi.aterm.AFun;
import nl.cwi.aterm.ATerm;
import nl.cwi.aterm.ATermFactory;
import nl.cwi.aterm.ATermList;

import nl.cwi.aterm.saa.ATermContentHandler;
import nl.cwi.aterm.saa.SAAException;

/**
 * Helps with the sending of terms without annotations
 *
 * @author Martin Bravenboer, 
 *         <a href="mailto:mbravenb@cs.uu.nl">mbravenb@cs.uu.nl</a>
 * @version 1.0, 26-05-2002
 */
public class NoAnnosHelper extends ContentForwarder {

  private final ATermList NO_ANNOS;

  public NoAnnosHelper(ATermContentHandler to, ATermFactory factory) {
    super(to);
    NO_ANNOS = factory.makeList();
  }

  public void value(int value) throws SAAException {
    value(value, NO_ANNOS);
  }

  public void value(String value) throws SAAException {
    value(value, NO_ANNOS);
  }

  public void value(double value) throws SAAException {
    value(value, NO_ANNOS);
  }

  public void startApplication(String function) throws SAAException {
    startApplication(function, NO_ANNOS);
  }

  public void startList() throws SAAException {
    startList(NO_ANNOS);
  }
}

package nl.cwi.aterm.helpers;

import nl.cwi.aterm.ATerm;
import nl.cwi.aterm.ATermList;
import nl.cwi.aterm.visitor.ATermVisitFailure;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ATermIterator implements Iterator {

  private ATermList _tail;
  private boolean _hasNext;

  public ATermIterator(ATermList list) {
    super();
    _tail = list;
    validate();
  }

  private void validate() {
    if(_tail == null || _tail.getLength() == 0) {
      _hasNext = false;
    }
    else {
      _hasNext = true;
    }
  }
  
  public Object next() throws NoSuchElementException {
    if(!hasNext()) {
      throw new NoSuchElementException();
    }

    ATerm result = _tail.getFirst();

    _tail = _tail.getNext();
    validate();

    return result;
  }

  public boolean hasNext() {
    return _hasNext;
  }

  public void remove() {
    throw new UnsupportedOperationException("Remove is not supported by this Iterator implementation");
  }
}

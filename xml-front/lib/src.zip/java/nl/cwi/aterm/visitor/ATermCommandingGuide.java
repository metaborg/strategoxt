package nl.cwi.aterm.visitor;

import nl.cwi.aterm.*;

import org.mbravenboer.visitor.CommandingGuide;

/**
 * @author Martin Bravenboer
 * @version 1.0, 14/03/02
 */
public interface ATermCommandingGuide
    extends CommandingGuide {

  public void guide(ATermInt arg)         throws ATermVisitFailure;
  public void guide(ATermReal arg)        throws ATermVisitFailure;
  public void guide(ATermAppl arg)        throws ATermVisitFailure;
  public void guide(ATermList arg)        throws ATermVisitFailure;
  public void guide(ATermPlaceholder arg) throws ATermVisitFailure;
  public void guide(ATermBlob arg)        throws ATermVisitFailure;
}

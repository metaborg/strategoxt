package nl.cwi.aterm.visitor.helpers;

import nl.cwi.aterm.visitor.ATermVisitor;
import nl.cwi.aterm.visitor.ATermVisitFailure;

import nl.cwi.aterm.*;

/**
 * Abstract visitor implementation that forwards every specific 
 * visit call to a generics visit methods for an ATerm. 
 * Visitor implementations that want to implement a generic 
 * operation over ATerms can implements this method.
 *
 * @author Martin Bravenboer
 * @version 1.0, 14/03/02
 */
public abstract class GenericATermVisitor
    implements ATermVisitor {

  /**
   * Visit method for all ATerms. Generic implementations should
   * implement this method.
   */
  public abstract void visitATerm(ATerm arg) throws ATermVisitFailure;
  
  /** 
   * Forwards this visit call to the generic visitATerm method.
   */
  public void visit(ATermInt arg)  throws ATermVisitFailure {
      visitATerm(arg);
  }
  
  /** 
   * Forwards this visit call to the generic visitATerm method.
   */
  public void visit(ATermReal arg) throws ATermVisitFailure {
      visitATerm(arg);
  }
  
  /** 
   * Forwards this visit call to the generic visitATerm method.
   */
  public void visit(ATermAppl arg) throws ATermVisitFailure {
      visitATerm(arg);
  }
  
  /** 
   * Forwards this visit call to the generic visitATerm method.
   */
  public void visit(ATermList arg) throws ATermVisitFailure {
      visitATerm(arg);
  }
  
  /** 
   * Forwards this visit call to the generic visitATerm method.
   */
  public void visit(ATermPlaceholder arg) throws ATermVisitFailure {
      visitATerm(arg);
  }
  
  /** 
   * Forwards this visit call to the generic visitATerm method.
   */
  public void visit(ATermBlob arg) throws ATermVisitFailure {
      visitATerm(arg);
  }
}

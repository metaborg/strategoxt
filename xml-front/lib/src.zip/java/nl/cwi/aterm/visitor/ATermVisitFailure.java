package nl.cwi.aterm.visitor;

public class ATermVisitFailure
    extends Exception {

  public ATermVisitFailure(String msg){
    super(msg);
  }

  public ATermVisitFailure(String msg, Exception cause){
    super(msg, cause);
  }
}

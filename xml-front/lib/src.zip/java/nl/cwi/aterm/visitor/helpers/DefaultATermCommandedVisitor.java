package nl.cwi.aterm.visitor.helpers;

import nl.cwi.aterm.visitor.ATermCommandedVisitor;
import nl.cwi.aterm.visitor.ATermVisitFailure;
import nl.cwi.aterm.*;

public class DefaultATermCommandedVisitor
    implements ATermCommandedVisitor {

  public void discover(ATermInt arg)  throws ATermVisitFailure {}
  public void bypassing(ATermInt arg)  throws ATermVisitFailure {}
  public void leave(ATermInt arg)  throws ATermVisitFailure {}

  public void discover(ATermReal arg) throws ATermVisitFailure {}
  public void bypassing(ATermReal arg) throws ATermVisitFailure {}
  public void leave(ATermReal arg) throws ATermVisitFailure {}

  public void discover(ATermAppl arg) throws ATermVisitFailure {}
  public void bypassing(ATermAppl arg) throws ATermVisitFailure {}
  public void leave(ATermAppl arg) throws ATermVisitFailure {}

  public void discover(ATermList arg) throws ATermVisitFailure {}
  public void bypassing(ATermList arg) throws ATermVisitFailure {}
  public void leave(ATermList arg) throws ATermVisitFailure {}

  public void discover(ATermPlaceholder arg) throws ATermVisitFailure {}
  public void bypassing(ATermPlaceholder arg) throws ATermVisitFailure {}
  public void leave(ATermPlaceholder arg) throws ATermVisitFailure {}

  public void discover(ATermBlob arg) throws ATermVisitFailure {}
  public void bypassing(ATermBlob arg) throws ATermVisitFailure {}
  public void leave(ATermBlob arg) throws ATermVisitFailure {}
}

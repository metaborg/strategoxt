package nl.cwi.aterm.visitor;

import org.mbravenboer.visitor.Visitable;

public interface ATermVisitable
    extends Visitable {

  public void accept(ATermVisitor visitor)        throws ATermVisitFailure;
  public void accept(ATermCommandingGuide guide)  throws ATermVisitFailure;
}


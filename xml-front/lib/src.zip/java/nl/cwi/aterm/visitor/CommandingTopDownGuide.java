package nl.cwi.aterm.visitor;

import nl.cwi.aterm.*;
import nl.cwi.aterm.visitor.ATermCommandingGuide;
import nl.cwi.aterm.visitor.ATermVisitFailure;
import nl.cwi.aterm.visitor.ATermCommandedVisitor;

import java.util.Iterator;

/**
 * @author Martin Bravenboer
 * @version 1.0, 14/03/02
 */
public class CommandingTopDownGuide
    implements ATermCommandingGuide {

  private ATermCommandedVisitor _visitor;

  public CommandingTopDownGuide(ATermCommandedVisitor visitor) {
    super();
    _visitor = visitor;
  }

  public void guide(ATermInt arg)  throws ATermVisitFailure {
    _visitor.discover(arg);
    _visitor.leave(arg);
  }

  public void guide(ATermReal arg) throws ATermVisitFailure {
    _visitor.discover(arg);
    _visitor.leave(arg);
  }

  public void guide(ATermBlob arg) throws ATermVisitFailure {
    _visitor.discover(arg);
    _visitor.leave(arg);
  }

  public void guide(ATermAppl arg) throws ATermVisitFailure {
    _visitor.discover(arg);

    Iterator iterator = arg.getArguments().iterator();
    while(iterator.hasNext()) {
      ATerm term = (ATerm) iterator.next(); //TODO: remove cast when using Java Generics
      term.accept(this);
      //TODO: decide whether we want 'bypassing' here
    }

    _visitor.leave(arg);
  }

  public void guide(ATermList arg) throws ATermVisitFailure {
    _visitor.discover(arg);

    Iterator iterator = arg.iterator();
    while(iterator.hasNext()) {
      ATerm term = (ATerm) iterator.next(); //TODO: remove cast when using Java Generics
      term.accept(this);
      //TODO: decide whether we want 'bypassing' here
    }

    _visitor.leave(arg);
  }

  public void guide(ATermPlaceholder arg) throws ATermVisitFailure {
    //TODO: check out in which cases a PlaceHolder is used.
    System.err.println("TODO: Placeholder");
  }
}

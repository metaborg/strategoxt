package nl.cwi.aterm.visitor;

import nl.cwi.aterm.*;
import org.mbravenboer.visitor.Visitor;

/**
 * @author Martin Bravenboer
 * @version 1.0, 14/03/02
 */
public interface ATermVisitor
    extends Visitor {

  public void visit(ATermInt arg)         throws ATermVisitFailure;
  public void visit(ATermReal arg)        throws ATermVisitFailure;
  public void visit(ATermAppl arg)        throws ATermVisitFailure;
  public void visit(ATermList arg)        throws ATermVisitFailure;
  public void visit(ATermPlaceholder arg) throws ATermVisitFailure;
  public void visit(ATermBlob arg)        throws ATermVisitFailure;
}
